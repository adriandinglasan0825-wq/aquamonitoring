import React, { useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Dimensions,
  Image,
} from "react-native";
import historyIcon from '../../assets/clock-with-circular-arrow.png';
import homeIcon from '../../assets/home.png';
import settingsIcon from '../../assets/setting.png';

export default function HistoryScreen({ navigation }) {
  React.useLayoutEffect(() => {
    navigation.setOptions({ headerShown: false });
  }, [navigation]);

  const [activeIndex, setActiveIndex] = useState(null);

  // Summary of recent days
  const [historyData] = useState([
    { date: "02/03/25", activity: "Sensor Reading", status: "Critical", color: "#FF3B30" },
    { date: "02/02/25", activity: "Sensor Reading", status: "Warning", color: "#FFCC00" },
    { date: "02/01/25", activity: "Sensor Reading", status: "Stable", color: "#34C759" },
  ]);

  // Generate mock 24-hour water data
  const generateHourlyData = () => {
    return Array.from({ length: 24 }, (_, i) => ({
      hour: `${i}:00 - ${i + 1}:00`,
      temperature: (28 + Math.random() * 3).toFixed(1), // °C
      ph: (7 + Math.random() * 0.5).toFixed(2),
      dissolvedO2: (5 + Math.random() * 2).toFixed(2), // mg/L
      ammonia: (Math.random() * 0.05).toFixed(3), // mg/L
    }));
  };

  const [hourlyData] = useState(generateHourlyData());

  const toggleDropdown = (index) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.headerRow}>
        <Text style={styles.title}>History</Text>
        <TouchableOpacity onPress={() => alert("Notifications")}>
          <Text style={styles.bell}>🔔</Text>
        </TouchableOpacity>
      </View>

      {/* Action Buttons */}
      <View style={styles.actionRow}>
        <TouchableOpacity
          style={styles.downloadButton}
          onPress={() => alert("Download")}
        >
          <Text style={styles.downloadText}>⬇️ Download</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.sortButton}
          onPress={() => alert("Sort")}
        >
          <Text style={styles.sortText}>⇅ Sort</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.filterButton}
          onPress={() => alert("Filter")}
        >
          <Text style={styles.filterText}>🔍 Filter</Text>
        </TouchableOpacity>
      </View>

      {/* Table Header */}
      <View style={styles.tableHeader}>
        <Text style={[styles.headerText, { flex: 1 }]}>Date</Text>
        <Text style={[styles.headerText, { flex: 1.2 }]}>Activity</Text>
        <Text style={[styles.headerText, { flex: 1 }]}>Status</Text>
        <Text style={[styles.headerText, { flex: 0.6 }]}>More</Text>
      </View>

      {/* Table Body */}
      <ScrollView style={styles.scrollArea} contentContainerStyle={{ paddingBottom: 120 }}>
        {historyData.map((item, index) => (
          <View key={index} style={styles.rowContainer}>
            {/* Row */}
            <View style={styles.tableRow}>
              <Text style={[styles.cellText, { flex: 1 }]}>{item.date}</Text>
              <Text style={[styles.cellText, { flex: 1.2 }]}>{item.activity}</Text>
              <View style={[styles.statusWrapper, { flex: 1 }]}>
                <View
                  style={[styles.statusDot, { backgroundColor: item.color }]}
                />
                <Text style={styles.statusText}>{item.status}</Text>
              </View>
              <TouchableOpacity
                style={[styles.moreButton, { flex: 0.6 }]}
                onPress={() => toggleDropdown(index)}
              >
                <Text style={styles.moreIcon}>
                  {activeIndex === index ? "▲" : "▼"}
                </Text>
              </TouchableOpacity>
            </View>

            {/* Dropdown (hourly details) */}
            {activeIndex === index && (
              <View style={styles.dropdownArea}>
                <Text style={styles.dropdownHeader}>
                  24-Hour Water Quality Data
                </Text>

                <View style={styles.dataHeader}>
                  <Text style={[styles.dataCol, { flex: 1 }]}>Time</Text>
                  <Text style={[styles.dataCol, { flex: 1 }]}>Temp (°C)</Text>
                  <Text style={[styles.dataCol, { flex: 1 }]}>pH</Text>
                  <Text style={[styles.dataCol, { flex: 1 }]}>O₂ (mg/L)</Text>
                  <Text style={[styles.dataCol, { flex: 1 }]}>NH₃ (mg/L)</Text>
                </View>

                {hourlyData.map((hour, i) => (
                  <View key={i} style={styles.hourRow}>
                    <Text style={[styles.dataCell, { flex: 1 }]}>{hour.hour}</Text>
                    <Text style={[styles.dataCell, { flex: 1 }]}>{hour.temperature}</Text>
                    <Text style={[styles.dataCell, { flex: 1 }]}>{hour.ph}</Text>
                    <Text style={[styles.dataCell, { flex: 1 }]}>{hour.dissolvedO2}</Text>
                    <Text style={[styles.dataCell, { flex: 1 }]}>{hour.ammonia}</Text>
                  </View>
                ))}
              </View>
            )}
          </View>
        ))}
      </ScrollView>

      {/* Footer Navigation */}
      <View style={styles.footer}>
              <TouchableOpacity style={styles.footerButton} onPress={() => navigation.navigate('History')}>
                <Image source={historyIcon} style={styles.footerIcon} />
      
                <Text style={styles.footerLabel}>History</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.footerButton} onPress={() => navigation.navigate('Home')}>
                          <Image source={homeIcon} style={styles.footerIcon} />
                <Text style={styles.footerLabel}>Home</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.footerButton} onPress={() => navigation.navigate('Settings')}>
                          <Image source={settingsIcon} style={styles.footerIcon} />
                <Text style={styles.footerLabel}>Settings</Text>
              </TouchableOpacity>
            </View>
    </View>
  );
}

// ---------------------------
// Styles
// ---------------------------
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    paddingTop: 40,
    paddingHorizontal: 20,
  },
  headerRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 15,
  },
  title: {
    fontSize: 26,
    fontWeight: "bold",
    color: "#000",
  },
  bell: { fontSize: 24 },
  actionRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 10,
    justifyContent: "space-between",
  },
  downloadButton: {
    backgroundColor: "#2ECC71",
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  downloadText: {
    color: "#fff",
    fontWeight: "bold",
  },
  sortButton: {
    backgroundColor: "#f2f2f2",
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  sortText: { color: "#333", fontWeight: "500" },
  filterButton: {
    backgroundColor: "#f2f2f2",
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  filterText: { color: "#333", fontWeight: "500" },
  tableHeader: {
    flexDirection: "row",
    backgroundColor: "#E0E0E0",
    borderRadius: 10,
    paddingVertical: 10,
    paddingHorizontal: 10,
    marginBottom: 8,
  },
  headerText: {
    fontWeight: "bold",
    color: "#333",
    fontSize: 13,
  },
  rowContainer: {
    backgroundColor: "#F7F7F7",
    borderRadius: 10,
    marginVertical: 4,
    overflow: "hidden",
  },
  tableRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 12,
    paddingHorizontal: 10,
  },
  cellText: { color: "#333", fontSize: 13 },
  statusWrapper: { flexDirection: "row", alignItems: "center" },
  statusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 6,
  },
  statusText: { fontSize: 13, color: "#333" },
  moreButton: { alignItems: "center" },
  moreIcon: { fontSize: 16, color: "#555" },
  dropdownArea: {
    backgroundColor: "#f0f0f0",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderTopWidth: 1,
    borderTopColor: "#ddd",
  },
  dropdownHeader: {
    fontWeight: "600",
    fontSize: 14,
    marginBottom: 6,
    textAlign: "center",
  },
  dataHeader: {
    flexDirection: "row",
    backgroundColor: "#ddd",
    borderRadius: 8,
    paddingVertical: 6,
    marginBottom: 4,
  },
  dataCol: {
    textAlign: "center",
    fontWeight: "600",
    fontSize: 12,
  },
  hourRow: {
    flexDirection: "row",
    justifyContent: "space-around",
    borderBottomWidth: 0.5,
    borderColor: "#ddd",
    paddingVertical: 6,
  },
  dataCell: {
    textAlign: "center",
    fontSize: 12,
    color: "#333",
  },
  scrollArea: { flex: 1 },
  footer: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    backgroundColor: "#f9f9f9",
    paddingVertical: 10,
    borderTopWidth: 1,
    borderTopColor: "#ddd",
    position: "absolute",
    bottom: 0,
    width: Dimensions.get("window").width,
  },
  footerButton: {
     alignItems: "center", flex: 1 
    },
   footerIcon: {
  width: 26,      // change size as needed
  height: 26,
  marginBottom: 4,
  resizeMode: 'contain', // keeps the aspect ratio
},
});

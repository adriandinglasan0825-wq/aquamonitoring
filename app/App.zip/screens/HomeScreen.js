import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  View, Text, TouchableOpacity, Image, StyleSheet, SafeAreaView, 
  Dimensions, ScrollView, TextInput, Modal, Animated 
} from 'react-native';
import { LineChart } from 'react-native-chart-kit';
import { useFocusEffect } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import historyIcon from '../../assets/clock-with-circular-arrow.png';
import homeIcon from '../../assets/home.png';
import settingsIcon from '../../assets/setting.png';

export default function HomeScreen({ navigation }) {
  const [showFeedModal, setShowFeedModal] = useState(false);
  const [showSavedPopup, setShowSavedPopup] = useState(false);
  const [feedTime, setFeedTime] = useState('');
  const [feedQuantity, setFeedQuantity] = useState('');
  const fadeSavedAnim = useRef(new Animated.Value(0)).current;
  const [showNotificationModal, setShowNotificationModal] = useState(false);

  const [safeRanges, setSafeRanges] = useState({
    temperature: { min: 28, max: 31 },
    ph: { min: 7.0, max: 8.5 },
    do: { min: 5, max: 7 },
    ammonia: { min: 0, max: 0.02 }
  });

  // 💧 Live water data
  const [waterData, setWaterData] = useState({
    temperature: 30.0,
    ph: 7.5,
    do: 6.2,
    ammonia: 0.01,
  });

  // 📊 Chart data
  const [chartData, setChartData] = useState({
    labels: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
    datasets: [{ data: [70,72,74,76,75,77,80] }],
  });

  // 🌐 Fetch real sensor data from your Pi server
  useEffect(() => {
    const fetchSensorData = async () => {
      try {
        const response = await fetch('http://192.168.1.8:3000/api/sensors/live');
        const data = await response.json();

        if (data) {
          setWaterData({
            temperature: data.temperature ?? waterData.temperature,
            ph: data.ph ?? waterData.ph,
            do: data.do ?? waterData.do,
            ammonia: data.ammonia ?? waterData.ammonia,
          });
        }
      } catch (error) {
        console.error("❌ Failed to fetch sensor data:", error.message);
      }
    };

    fetchSensorData(); // first fetch
    const interval = setInterval(fetchSensorData, 5000); // every 5s

    return () => clearInterval(interval);
  }, []);

  // 🧠 Load saved safe ranges when focused
  useFocusEffect(
    useCallback(() => {
      const loadRanges = async () => {
        try {
          const saved = await AsyncStorage.getItem('sensorRanges');
          if (saved) {
            const parsed = JSON.parse(saved);
            const normalized = {};
            for (const key in parsed) {
              normalized[key] = {};
              for (const bound in parsed[key]) {
                normalized[key][bound] = parseFloat(parsed[key][bound]);
              }
            }
            setSafeRanges(normalized);
          }
        } catch (e) {
          console.error('Failed to load sensor ranges', e);
        }
      };
      loadRanges();
    }, [])
  );

  // 🧠 Save feed
  const handleSave = () => {
    setShowFeedModal(false);
    setShowSavedPopup(true);
    Animated.timing(fadeSavedAnim, { toValue: 1, duration: 300, useNativeDriver: true }).start();
    setTimeout(() => {
      Animated.timing(fadeSavedAnim, { toValue: 0, duration: 300, useNativeDriver: true }).start(() => setShowSavedPopup(false));
    }, 2000);
  };

  // 🎨 Helper: safe vs warning color
  const getValueColor = (type, value) => {
    const range = safeRanges[type];
    if (!range) return '#000';
    switch (type) {
      case 'ammonia':
        return value <= range.max ? '#32CD32' : '#FF4C4C';
      default:
        return value >= range.min && value <= range.max ? '#32CD32' : '#FF4C4C';
    }
  };

  // ⚠️ Alerts
  const alerts = [];
  if (waterData.temperature > safeRanges.temperature.max) alerts.push('Your water temperature is too high.');
  else if (waterData.temperature < safeRanges.temperature.min) alerts.push('Your water temperature is too low.');
  if (waterData.ph > safeRanges.ph.max) alerts.push('Your pH level is too high.');
  else if (waterData.ph < safeRanges.ph.min) alerts.push('Your pH level is too low.');
  if (waterData.do > safeRanges.do.max) alerts.push('Dissolved oxygen is too high.');
  else if (waterData.do < safeRanges.do.min) alerts.push('Dissolved oxygen is too low.');
  if (waterData.ammonia > safeRanges.ammonia.max) alerts.push('Ammonia level is too high.');

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.topBar}>
        <Text style={styles.homeTitle}>Home</Text>
        <TouchableOpacity
          style={styles.notificationButton}
          onPress={() => setShowNotificationModal(true)}>
          <Text style={{ fontSize: 24 }}>🔔</Text>
          {alerts.length > 0 && <View style={styles.notificationBadge} />}
        </TouchableOpacity>
      </View>

      {/* Saved Popup */}
      {showSavedPopup && (
        <Animated.View style={[styles.popup, { opacity: fadeSavedAnim }]}>
          <Text style={styles.popupText}>💾 Saved!</Text>
        </Animated.View>
      )}

      {/* Main content */}
      <View style={{ flex: 1, width: '100%' }}>
        <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          <View style={styles.mainContent}>
            {/* Water Data Boxes */}
            <View style={styles.row}>
              <View style={[styles.dataBox, { borderColor: '#FFD700' }]}>
                <Text style={styles.label}>🌡 Water Temp</Text>
                <Text style={[styles.value, { color: getValueColor('temperature', waterData.temperature) }]}>
                  {waterData.temperature.toFixed(1)}°C
                </Text>
                <Text style={styles.safeRange}>
                  Safe: {safeRanges.temperature.min}°C - {safeRanges.temperature.max}°C
                </Text>
              </View>
              <View style={[styles.dataBox, { borderColor: '#FF4C4C' }]}>
                <Text style={styles.label}>🔴 pH Level</Text>
                <Text style={[styles.value, { color: getValueColor('ph', waterData.ph) }]}>
                  {waterData.ph.toFixed(2)}
                </Text>
                <Text style={styles.safeRange}>
                  Safe: {safeRanges.ph.min} - {safeRanges.ph.max}
                </Text>
              </View>
            </View>

            <View style={styles.row}>
              <View style={[styles.dataBox, { borderColor: '#32CD32' }]}>
                <Text style={styles.label}>🟢 Dissolved O₂</Text>
                <Text style={[styles.value, { color: getValueColor('do', waterData.do) }]}>
                  {waterData.do.toFixed(1)} mg/L
                </Text>
                <Text style={styles.safeRange}>
                  Safe: {safeRanges.do.min} - {safeRanges.do.max} mg/L
                </Text>
              </View>
              <View style={[styles.dataBox, { borderColor: '#32CD32' }]}>
                <Text style={styles.label}>🟢 Ammonia</Text>
                <Text style={[styles.value, { color: getValueColor('ammonia', waterData.ammonia) }]}>
                  {waterData.ammonia.toFixed(3)} ppm
                </Text>
                <Text style={styles.safeRange}>
                  Safe: {safeRanges.ammonia.min} - {safeRanges.ammonia.max} ppm
                </Text>
              </View>
            </View>

            {/* Feed Button */}
            <TouchableOpacity style={styles.feedButton} onPress={() => setShowFeedModal(true)}>
              <Text style={styles.feedButtonText}>Feed Fish</Text>
            </TouchableOpacity>

            {/* Chart */}
            <View style={styles.chartContainer}>
              <LineChart
                data={chartData}
                width={Dimensions.get('window').width - 40}
                height={180}
                yAxisSuffix="°C"
                chartConfig={{
                  backgroundGradientFrom: '#2a5298',
                  backgroundGradientTo: '#1e3c72',
                  color: (opacity = 1) => `rgba(255,255,255,${opacity})`,
                  labelColor: (opacity = 1) => `rgba(255,255,255,${opacity})`,
                  decimalPlaces: 1,
                  propsForDots: { r: '3', strokeWidth: '1', stroke: '#00ffcc' }
                }}
                bezier
                style={styles.chart}
              />
            </View>
          </View>
        </ScrollView>
      </View>

      {/* Footer Navigation */}
      <View style={styles.footer}>
        <TouchableOpacity style={styles.footerButton} onPress={() => navigation.navigate('History')}>
          <Image source={historyIcon} style={styles.footerIcon} />
          <Text style={styles.footerLabel}>History</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.footerButton} onPress={() => navigation.navigate('Home')}>
          <Image source={homeIcon} style={styles.footerIcon} />
          <Text style={styles.footerLabel}>Home</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.footerButton} onPress={() => navigation.navigate('Settings')}>
          <Image source={settingsIcon} style={styles.footerIcon} />
          <Text style={styles.footerLabel}>Settings</Text>
        </TouchableOpacity>
      </View>

      {/* Feed Modal */}
      <Modal animationType="slide" transparent={true} visible={showFeedModal}>
        <View style={styles.modalBackground}>
          <View style={styles.modalContainer}>
            <Text style={styles.modalTitle}>Feed Fish</Text>
            <TextInput
              placeholder="Set Time (e.g., 08:00 AM)"
              style={styles.input}
              value={feedTime}
              onChangeText={setFeedTime}
            />
            <TextInput
              placeholder="Set Quantity (grams)"
              style={styles.input}
              value={feedQuantity}
              onChangeText={setFeedQuantity}
              keyboardType="numeric"
            />
            <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
              <Text style={styles.saveButtonText}>Save</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.saveButton, { backgroundColor: '#ccc', marginTop: 10 }]}
              onPress={() => setShowFeedModal(false)}>
              <Text style={[styles.saveButtonText, { color: '#333' }]}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Notification Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={showNotificationModal}
        onRequestClose={() => setShowNotificationModal(false)}>
        <View style={styles.modalBackground}>
          <View style={[styles.modalContainer, { width: '80%' }]}>
            <Text style={styles.modalTitle}>Notifications</Text>

            {alerts.length === 0 ? (
              <Text style={{ textAlign: 'center', marginVertical: 20, fontSize: 16 }}>
                ✅ All readings are normal.
              </Text>
            ) : (
              <ScrollView style={{ maxHeight: 200, marginVertical: 10 }}>
                {alerts.map((alert, idx) => (
                  <Text key={idx} style={styles.alertText}>• {alert}</Text>
                ))}
              </ScrollView>
            )}

            <TouchableOpacity
              style={[styles.saveButton, { backgroundColor: '#254a70', marginTop: 20 }]}
              onPress={() => setShowNotificationModal(false)}>
              <Text style={styles.saveButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  topBar: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginTop: 50,
    
  },
  homeTitle: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#000000ff',
  },
  notificationButton: {
  padding: 6,
  borderRadius: 20,
  backgroundColor: 'transparent', // keep transparent or subtle bg
  position: 'relative',
},

notificationBadge: {
  position: 'absolute',
  top: 2,
  right: 2,
  width: 10,
  height: 10,
  borderRadius: 5,
  backgroundColor: '#FF4C4C',
  borderWidth: 1,
  borderColor: '#fff',
},

// Notification modal specific styles
alertText: {
  fontSize: 16,
  color: '#333',
  marginBottom: 8,
  paddingLeft: 10,
},

// If you want a more distinct Close button color on notification modal
saveButton: {
  backgroundColor: '#32CD32',  // default green button
  paddingVertical: 12,
  borderRadius: 10,
  width: '100%',
  marginTop: 10,
  alignItems: 'center',
},
saveButtonText: {
  color: '#fff',
  fontWeight: 'bold',
  textAlign: 'center',
},

  scrollContent: {
    paddingBottom: 20,
    alignItems: 'center',
  },
  mainContent: {
    marginTop: 20,
    alignItems: 'center',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginVertical: 8,
  },
  dataBox: {
    backgroundColor: '#fff',
    width: 140,
    height: 90,
    borderRadius: 25,
    marginHorizontal: 8,
    alignItems: 'center',
    justifyContent: 'space-around',
    borderWidth: 2.5,
    elevation: 3,
    paddingVertical: 10,
  },
  label: {
    fontSize: 11,
    color: '#333',
    textAlign: 'center',
  },
  value: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
    textAlign: 'center',
  },
  safeRange: {
    fontSize: 9,
    color: '#666',
    textAlign: 'center',
  },
  feedButton: {
    backgroundColor: '#254a70ff',
    paddingVertical: 12,
    width: Dimensions.get('window').width - 40,
    borderRadius: 10,
    marginVertical: 15,
  },
  feedButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  chartContainer: {
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 10,
  },
  chart: {
    borderRadius: 10,
  },
   footer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    backgroundColor: '#f9f9f9',
    paddingVertical: 10,
    borderTopWidth: 1,
    borderTopColor: '#ddd',
    position: 'absolute',
    bottom: 0,
    width: Dimensions.get('window').width,
  },

  footerButton: {
    alignItems: 'center',
    flex: 1,
  },

 footerIcon: {
  width: 26,      // change size as needed
  height: 26,
  marginBottom: 4,
  resizeMode: 'contain', // keeps the aspect ratio
},

  modalBackground: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    width: '85%',
    backgroundColor: '#fff',
    borderRadius: 15,
    padding: 20,
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 10,
    width: '100%',
    marginVertical: 5,
  },
  saveButton: {
    backgroundColor: '#32CD32',
    paddingVertical: 12,
    borderRadius: 10,
    width: '100%',
    marginTop: 10,
  },
  saveButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  popup: {
    position: 'absolute',
    top: 70,
    backgroundColor: '#87919bff',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
    zIndex: 100,
  },
  popupText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
  },
});
